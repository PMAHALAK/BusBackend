package com.bus.paymentservice.exception;

public class PaymentNotFoundWithIdException extends Exception {
public PaymentNotFoundWithIdException(String message) {
	super(message);
}
}

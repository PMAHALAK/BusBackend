package com.bus.customerissue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerissueApplicationTests {

	@Test
	void contextLoads() {
	}

}

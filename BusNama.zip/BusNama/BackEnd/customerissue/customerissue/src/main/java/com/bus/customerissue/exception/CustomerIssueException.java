package com.bus.customerissue.exception;

public class CustomerIssueException extends RuntimeException{

	public CustomerIssueException(String message) {
		super(message);
	}
}


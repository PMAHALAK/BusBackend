package com.bus.registration.service;

import com.bus.registration.model.Registration;

public interface RegistrationService {
public Registration save(Registration user);
}

